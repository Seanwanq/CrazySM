This folder is Siyuan Wang and Linglan Li's Week 2 homework code.

This project is built with CMake and Ninja-build.

Latest MSVC, GCC and Clang compiler are all acceptable.

If you want to run a specific file, plese uncomment the specified line in CMakeLists.txt.

For example, if you want to run `fcc.c`, please uncomment 
```
add_executable(monte_carlo_simulation_of_hard_spheres fcc.c absolute-path.c)
```
and comment other `add_executable` lines.

VSCode CMake plugins are recommended.
