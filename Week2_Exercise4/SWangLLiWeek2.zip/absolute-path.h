﻿#ifndef ABSOLUTE_PATH_H
#define ABSOLUTE_PATH_H

// Comment this line if you are using MSVC
void GetAbsoluteFileName(char *, char *);

#endif